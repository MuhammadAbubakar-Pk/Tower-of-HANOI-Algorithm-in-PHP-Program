<?php


define('SOLVE_INPUT_NAME','solve_method',true);
define('DISKS_INPUT_NAME','disk_count',true);

define('OUTPUT_FULL','full_draw',true);
define('OUTPUT_SIMPLE','simple_solve',true);
define('OUTPUT_MOVES','just_moves',true);

define('DEFAULT_DISKS_COUNT',3,true);

define('COLUMN_FIRST','A',true);
define('COLUMN_SECOND','B',true);
define('COLUMN_THIRD','C',true);

define('SUBMIT_BTN_NAME','submit',true);
define('SUBMIT_BTN_VALUE','Solve',true);

define('HEAD_PAGE_TITLE','Tower Of Hanoi',true);
define('HOME_PAGE_TITLE','<i class="zmdi zmdi-github"></i> Tower Of Hanoi',true);
define('HANOI_SOLVE_PAGE_TITLE','<i class="zmdi zmdi-home"></i> Home',true);

define('TOPMARGIN_KEY','TOPMARGIN',true);
define('DISK_SPACE',25,true);
define('DISK_HEIGHT',20,true);


